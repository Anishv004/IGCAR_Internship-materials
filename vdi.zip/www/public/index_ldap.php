<?php    $db=new stdclass();
    // $db->icno=$username;
     $db->icno=10000;
     $db->unit='IGCAR';
// $db->unit=$userdata->unitoff;
     $jsn = json_encode($db);
     $url = "http://10.30.1.71/auth/login/emp/".base64_encode($jsn);
     $user_data_all = file_get_contents($url); 
	 
	
	 var_dump($user_data_all);
	 $uad = json_decode($user_data_all); 
echo "<br>";
	 echo $uad->displayname; 
	  
	  
	  echo $uad->orgdisp; 
	
?>